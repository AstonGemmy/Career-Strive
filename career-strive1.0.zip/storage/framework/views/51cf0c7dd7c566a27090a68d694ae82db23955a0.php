<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/astongemmy/Algrith/Development/Laravel/Applications/Career-Strive/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>