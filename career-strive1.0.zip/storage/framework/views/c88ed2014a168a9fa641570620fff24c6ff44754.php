<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
    <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="rgba(157, 23, 77, 1)" />
        <meta name="msapplication-TileColor" content="rgba(157, 23, 77, 1)" />
        <meta name="msapplication-TileImage" content="images/favicon/ms-icon-144x144.png" />
        
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />

        <meta name="description" content="Computer Based Test Portal" />
        <meta property="og:description" name="description" content="Computer Based Test Portal" />
        <meta property="og:author" name="author" content="Aston Gemmy" />
        <meta property="og:keywords" name="keywords" content="Computer Based Test Portal" />
        <meta property="og:image" name="image" content="/images/logo/algrith.png" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Styles -->
        <link rel="stylesheet" type="text/css" href="/css/fonts.css"/>
        <link rel="stylesheet" type="text/css" href="/css/icons.css"/>
        <link rel="stylesheet" type="text/css" href="/css/app.css" />

        <!-- Scripts -->
        <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
        <!-- <script src="<?php echo e(mix('js/app.js')); ?>" defer></script> -->
    </head>
    <body class="antialiased">
        <div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div>
    </body>

    <script src="js/app.js" defer></script>

    <?php if(Auth::check()): ?>
    <script> window.AuthUser = <?php echo json_encode(Auth::user());; ?>; </script>
    <?php else: ?>
    <script> window.AuthUser = {}; </script>
    <?php endif; ?>

</html>
<?php /**PATH /home/astongemmy/Algrith/Development/Laravel/Applications/Career-Strive/resources/views/app.blade.php ENDPATH**/ ?>