<template>
    <div class="flex flex-wrap justify-between items-center text-white text-xl mx-auto md:mx-0 py-4">
        <span class="flex justify-center items-center cursor-pointer w-8 h-8 mr-4 bg-blue-800 rounded-full">
            <i class="fab fa-facebook-f"></i>
        </span>
        <span class="flex justify-center items-center cursor-pointer w-8 h-8 mr-4 bg-pink-600 rounded-full">
            <i class="fab fa-instagram"></i>
        </span>
        <span class="flex justify-center items-center cursor-pointer w-8 h-8 mr-4 bg-red-600 rounded-full">
            <i class="fab fa-pinterest"></i>
        </span>
        <span class="flex justify-center items-center cursor-pointer w-8 h-8 mr-4 bg-blue-500 rounded-full">
            <i class="fab fa-twitter"></i>
        </span>
        <span class="flex justify-center items-center cursor-pointer w-8 h-8 bg-blue-900 rounded-full">
            <i class="fab fa-linkedin"></i>
        </span>
    </div>
</template>